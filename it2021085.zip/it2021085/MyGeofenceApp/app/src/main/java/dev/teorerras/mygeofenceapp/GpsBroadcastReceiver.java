package dev.teorerras.mygeofenceapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.widget.Toast;

public class GpsBroadcastReceiver extends BroadcastReceiver {

    private static final int STOPPED_BY_RECEIVER = 0;
    private static final int STARTED_BY_RECEIVER = 1;
    private static int STATUS = -1;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null) {
            if (intent.getAction().equals(LocationManager.PROVIDERS_CHANGED_ACTION)) {
                if (isGpsEnabled(context)) {
                    if(STATUS == STOPPED_BY_RECEIVER && !MainActivity.serviceRunning){
                        STATUS = STARTED_BY_RECEIVER;
                        startTracking(context);
                        toMain(context);
                    }
                } else {
                    if(MainActivity.serviceRunning){
                        STATUS = STOPPED_BY_RECEIVER;
                        stopTracking(context);
                        toMain(context);
                    }
                }
            }
        }
    }
    public static boolean isGpsEnabled(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        return locationManager != null && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    private void startTracking(Context context){
        Intent intent = new Intent(context.getApplicationContext(), TrackingService.class);
        if(context.startService(intent) != null){
            Toast.makeText(context, "GPS signal acquired. Tracking service started", Toast.LENGTH_LONG).show();
        }
        else Toast.makeText(context, "GPS signal acquired. Could not start tracking service", Toast.LENGTH_LONG).show();
    }
    private void stopTracking(Context context){
        Intent intent = new Intent(context.getApplicationContext(), TrackingService.class);
        if(context.stopService(intent)){
            Toast.makeText(context, "Tracking service terminated due to GPS signal loss", Toast.LENGTH_LONG).show();
        }
        else Toast.makeText(context, "Tracking service is currently not running.", Toast.LENGTH_LONG).show();
    }

    private void toMain(Context context){
        Intent intent = new Intent(context.getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        context.startActivity(intent);
    }
}
