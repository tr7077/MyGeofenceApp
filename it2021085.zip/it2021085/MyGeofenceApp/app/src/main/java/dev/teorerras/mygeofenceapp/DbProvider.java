package dev.teorerras.mygeofenceapp;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class DbProvider extends ContentProvider {

    private UriMatcher uriMatcher;
    private static final String AUTHORITY = "dev.teorerras.mygeofenceapp";
    private static final String ADD_COORDINATES_PATH = "upsertCoordinates";
    private static final String GET_COORDINATES_PATH = "getCoordinates/#";
    private static final String CLEAR_COORDINATES_PATH = "clearCoordinatesTable";
    private static final String LAST_SESSION_ID_PATH = "lastSessionId";
    private static final int UPSERT_CODE = 0;
    private static final int GET_CODE = 1;
    private static final int CLEAR_CODE = 2;
    private static final int LAST_SESSION_ID_CODE = 3;


    @Override
    public boolean onCreate() {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTHORITY, ADD_COORDINATES_PATH, UPSERT_CODE);
        uriMatcher.addURI(AUTHORITY, GET_COORDINATES_PATH, GET_CODE);
        uriMatcher.addURI(AUTHORITY, CLEAR_COORDINATES_PATH, CLEAR_CODE);
        uriMatcher.addURI(AUTHORITY, LAST_SESSION_ID_PATH, LAST_SESSION_ID_CODE);
        return false;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {

        switch (uriMatcher.match(uri)){
            case GET_CODE:
                MyDatabase.initialize(getContext());
                int pointType = Integer.parseInt(uri.getLastPathSegment());
                MatrixCursor cursor = new MatrixCursor(new String[]{"id", "lat", "lng", "pt", "sid"});
                List<Coordinates> coordinatesList;
                if(pointType == 0) coordinatesList = MyDatabase.getCoordinatesDao().getAllCoordinatesBySession(MainActivity.LATEST_SESSION_ID);
                else coordinatesList = MyDatabase.getCoordinatesDao().getPointsBySession(pointType, MainActivity.LATEST_SESSION_ID);

                for(Coordinates c: coordinatesList){
                    cursor.addRow(new Object[]{c.id, c.latitude, c.longitude, c.pointType, c.session_id});
                }
                return cursor;

            case LAST_SESSION_ID_CODE:
                MyDatabase.initialize(getContext());
                int lastSessionId = MyDatabase.getCoordinatesDao().getLastSessionId();
                MatrixCursor cursor2 = new MatrixCursor(new String[]{"lastSessionId"});
                cursor2.addRow(new Object[]{lastSessionId});
                return cursor2;
        }

        return null;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        if(values == null) return null;

        switch (uriMatcher.match(uri)){
            case UPSERT_CODE:
                Coordinates coordinates = new Coordinates(values.getAsDouble("lat"), values.getAsDouble("lng"), values.getAsInteger("pt"), values.getAsInteger("sid"));
                MyDatabase.initialize(getContext());
                MyDatabase.getCoordinatesDao().upsertCoordinates(coordinates);
                break;
        }

        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {

        switch (uriMatcher.match(uri)){
            case CLEAR_CODE:
                MyDatabase.initialize(getContext());
                MyDatabase.getCoordinatesDao().deleteAll();
                break;
        }

        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
