package dev.teorerras.mygeofenceapp;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.google.android.gms.maps.model.LatLng;

@Entity
public class Coordinates {

    @Ignore
    public static final int CIRCLE_POINT = 1;
    @Ignore
    public static final int ENTER_POINT = 2;
    @Ignore
    public static final int OUT_POINT = 3;

    public Coordinates(double latitude, double longitude, int pointType, int session_id) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.pointType = pointType;
        this.session_id = session_id;
        this.id = generateID();
    }

    @Ignore
    Coordinates(){}
    @Ignore
    Coordinates(LatLng latLng, int pointType){
        this.latitude = latLng.latitude;
        this.longitude = latLng.longitude;
        this.pointType = pointType;
        this.id = generateID();
    }
    @Ignore
    public LatLng getLatLng(){
        return new LatLng(this.latitude, this.longitude);
    }
    @Ignore
    private String generateID(){
        return String.valueOf((String.valueOf(this.latitude)+String.valueOf(this.longitude)+String.valueOf(this.pointType)+String.valueOf(this.session_id)).hashCode());
    }

    @PrimaryKey
    @NonNull
    public String id;
    @ColumnInfo(name = "latitude")
    public double latitude;
    @ColumnInfo(name = "longitude")
    public double longitude;
    @ColumnInfo(name = "pointType")
    public int pointType;
    @ColumnInfo(name = "session_id")
    public int session_id;


}
