package dev.teorerras.mygeofenceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import dev.teorerras.mygeofenceapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private BroadcastReceiver receiver;
    public static boolean serviceRunning = false;
    public static int LATEST_SESSION_ID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.setLocationsButton.setOnClickListener(v -> toMapActivity());
        binding.terminateTrackingButton.setOnClickListener(v -> terminateTracking());
        binding.resultsButton.setOnClickListener(v -> toResultsMapActivity());

        // next code up to line 52 is an easter egg. I only used it in production for testing but it seemed lovely so i decided to keep it
        binding.welcomeText.setOnClickListener(v -> {
            Thread t = new Thread(() ->{
                MyDatabase.initialize(getApplicationContext());
                MyDatabase.getCoordinatesDao().deleteAll();
            });
            t.start();
            try {
                t.join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            Toast.makeText(this, "Data cleared", Toast.LENGTH_LONG).show();
            LATEST_SESSION_ID = 0;
        });//------------------------------------------------------------------------------------------

        getLastSessionId();

        setUpBroadcastReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(serviceRunning){
            binding.serviceStatus.setText("Tracking: ON");
        }
        else{
            binding.serviceStatus.setText("Tracking: OFF");
        }
    }

    private void getLastSessionId(){
        Thread t = new Thread(() -> {

            ContentResolver resolver = getContentResolver();
            Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/lastSessionId");
            Cursor cursor = resolver.query(uri, null, null, null, null);

            if(cursor != null && cursor.moveToFirst()){
                LATEST_SESSION_ID = cursor.getInt(cursor.getColumnIndexOrThrow("lastSessionId"));
                cursor.close();
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private void toMapActivity(){
        Intent intent = new Intent(getApplicationContext(), MapActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }

    private void toResultsMapActivity(){
        Intent intent = new Intent(getApplicationContext(), ResultsMapActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(receiver);
    }

    private void terminateTracking(){
        Intent intent = new Intent(getApplicationContext(), TrackingService.class);
        if(stopService(intent)){
            Toast.makeText(this, "Tracking service terminated.", Toast.LENGTH_LONG).show();
            binding.serviceStatus.setText("Tracking: OFF");
        }
        else Toast.makeText(this, "Tracking service is currently not running.", Toast.LENGTH_LONG).show();
    }

    private void setUpBroadcastReceiver(){
        if(receiver == null) receiver = new GpsBroadcastReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocationManager.PROVIDERS_CHANGED_ACTION);
        registerReceiver(receiver, filter);
    }

}