package dev.teorerras.mygeofenceapp;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

import dev.teorerras.mygeofenceapp.databinding.ActivityMapBinding;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private ActivityMapBinding binding;
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    public static double RADIUS = 100;
    private ArrayList<Circle> circleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //-----> modifies what the back button or gesture does on every android device ---------------------------------------------
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                toMain();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
        //--------------------------------------------------------------------------------------------------

        // cancel button:
        binding.cancelButton.setOnClickListener(v -> finish());

        // start button
        binding.startButton.setOnClickListener(v -> {
            if(!GpsBroadcastReceiver.isGpsEnabled(getApplicationContext())){
                Toast.makeText(this, "Turn on location (GPS) first", Toast.LENGTH_LONG).show();
                return;
            }
            if(circleList.size() < 1){
                Toast.makeText(this, "No areas selected\nSelect areas first", Toast.LENGTH_LONG).show();
                return;
            }
            if(MainActivity.serviceRunning){
                Toast.makeText(this, "Tracking service already running\nStop it first to run new", Toast.LENGTH_LONG).show();
                return;
            }
            MainActivity.LATEST_SESSION_ID++;
            saveToDatabase();
            if(beginService()){
                Toast.makeText(this, "Tracking service started", Toast.LENGTH_LONG).show();
                finish();
            }
        });

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        circleList = new ArrayList<>();

        // check location permission and request if needed
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            initMap();
        }

    }

//    private void clearDatabase(){
//        Thread t = new Thread(() -> {
//            Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/clearCoordinatesTable");
//            ContentResolver resolver = this.getContentResolver();
//            resolver.delete(uri, null, null);
//        });
//        t.start();
//        try {
//            t.join();
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
//    }
    private void saveToDatabase(){
        ArrayList<LatLng> temp = new ArrayList<>();
        for(Circle c: circleList){
            temp.add(c.getCenter());
        }
        Thread t = new Thread(() -> {
            ContentResolver resolver = this.getContentResolver();
            Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/upsertCoordinates");
            for(LatLng l: temp){
                //Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/upsertCoordinates");
                ContentValues contentValues = new ContentValues();
                contentValues.put("lat", l.latitude);
                contentValues.put("lng", l.longitude);
                contentValues.put("pt", Coordinates.CIRCLE_POINT);
                contentValues.put("sid", MainActivity.LATEST_SESSION_ID);
                resolver.insert(uri, contentValues);
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        for(Circle c: circleList){
            c.remove();
        }
        circleList.clear();
    }
    private boolean beginService(){
        Intent intent = new Intent(getApplicationContext(), TrackingService.class);
        return startService(intent) != null;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                if (permissions[i].equals(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        initMap();
                    } else {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }
            }
        }
    }

    private void initMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ) {
            mMap.setMyLocationEnabled(true);
        }

        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this, location -> {
            if(location != null){
                LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15));
            }
        });


        mMap.setOnMapLongClickListener(latLng -> {
            CircleOptions options = new CircleOptions();
            options.center(latLng);
            options.radius(RADIUS);
            options.clickable(true);
            circleList.add(mMap.addCircle(options));
        });
        mMap.setOnCircleClickListener(circle -> {
            circleList.remove(circle);
            circle.remove();
        });
    }

    private void toMain(){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }

}