package dev.teorerras.mygeofenceapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Query;
import androidx.room.Upsert;

import java.util.List;

@Dao
public interface CoordinatesDao {

    @Upsert // insert if new or replace/update if it exists
    public void upsertCoordinates(Coordinates coordinates);

    @Delete
    public void deleteCoordinates(Coordinates coordinates);

    @Query("select * from Coordinates")
    public List<Coordinates> getAllCoordinates();
    @Query("select * from Coordinates where session_id == :session_id")
    public List<Coordinates> getAllCoordinatesBySession(int session_id);

    @Query("delete from Coordinates")
    public void deleteAll();

    @Query("select * from Coordinates where pointType == :pointType")
    public List<Coordinates> getPoints(int pointType);
    @Query("select * from Coordinates where pointType == :pointType and session_id == :session_id")
    public List<Coordinates> getPointsBySession(int pointType, int session_id);

    @Query("select max(session_id) as lastSessionId from Coordinates")
    public int getLastSessionId();
}
