package dev.teorerras.mygeofenceapp;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

import dev.teorerras.mygeofenceapp.databinding.ActivityMapBinding;
import dev.teorerras.mygeofenceapp.databinding.ActivityResultsMapBinding;

public class ResultsMapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private ActivityResultsMapBinding binding;
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private List<Coordinates> pointsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityResultsMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.homeButton.setOnClickListener(v -> finish());
        binding.restartButton.setOnClickListener(v -> restartService());

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        pointsList = getAllCoordinates();

        // check location permission and request if needed
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            initMap();
        }

    }

    private void restartService(){
        if(MainActivity.serviceRunning){
            Intent intent = new Intent(getApplicationContext(), TrackingService.class);
            if(stopService(intent)){
                Toast.makeText(this, "Tracking service terminated.", Toast.LENGTH_LONG).show();
            }
        }
        if(!GpsBroadcastReceiver.isGpsEnabled(getApplicationContext())){
            Toast.makeText(this, "Turn on location (GPS) first", Toast.LENGTH_LONG).show();
            return;
        }
        if(pointsList.isEmpty()){
            Toast.makeText(getApplicationContext(), "No data found.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(getApplicationContext(), TrackingService.class);
        startNewSessionWithLastCircles();
        if (startService(intent) != null) {
            Toast.makeText(getApplicationContext(), "Tracking service started", Toast.LENGTH_LONG).show();
        }
        recreate();

    }

    private void startNewSessionWithLastCircles(){
        MainActivity.LATEST_SESSION_ID++;
        Thread t = new Thread(() -> {
            ContentResolver resolver = this.getContentResolver();
            Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/upsertCoordinates");
            for(Coordinates c: pointsList){
                if(c.pointType == Coordinates.CIRCLE_POINT) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("lat", c.latitude);
                    contentValues.put("lng", c.longitude);
                    contentValues.put("pt", Coordinates.CIRCLE_POINT);
                    contentValues.put("sid", MainActivity.LATEST_SESSION_ID);
                    resolver.insert(uri, contentValues);
                }
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                if (permissions[i].equals(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        initMap();
                    } else {
                        getOnBackPressedDispatcher().onBackPressed();
                    }
                }
            }
        }
    }

    private void initMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.resultsMap);
        if (mapFragment != null) mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ) {
            mMap.setMyLocationEnabled(true);
        }

        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this, location -> {
            if(location != null){
                LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15));
            }
        });

        for(Coordinates c: pointsList){
            if(c.pointType == Coordinates.CIRCLE_POINT){
                CircleOptions circleOptions = new CircleOptions();
                circleOptions.center(c.getLatLng());
                circleOptions.radius(MapActivity.RADIUS);
                circleOptions.clickable(false);
                mMap.addCircle(circleOptions);
            }
            else {
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.draggable(false);
                markerOptions.position(c.getLatLng());
                if (c.pointType == Coordinates.ENTER_POINT) markerOptions.title("ENTER POINT - SESSION ID: "+c.session_id);
                else markerOptions.title("EXIT POINT - SESSION ID: "+c.session_id);
                mMap.addMarker(markerOptions);
            }
        }

    }

    private List<Coordinates> getAllCoordinates(){

        List<Coordinates> coordinatesList = new ArrayList<>();

        Thread t = new Thread(() -> {

            ContentResolver resolver = getContentResolver();
            Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/getCoordinates/0");
            Cursor cursor = resolver.query(uri, null, null, null, null);

            if(cursor != null && cursor.moveToFirst()){
                do{
                    Coordinates c = new Coordinates();
                    c.id = cursor.getString(cursor.getColumnIndexOrThrow("id"));
                    c.latitude = cursor.getDouble(cursor.getColumnIndexOrThrow("lat"));
                    c.longitude = cursor.getDouble(cursor.getColumnIndexOrThrow("lng"));
                    c.pointType = cursor.getInt(cursor.getColumnIndexOrThrow("pt"));
                    c.session_id = cursor.getInt(cursor.getColumnIndexOrThrow("sid"));
                    coordinatesList.add(c);
                } while(cursor.moveToNext());
                cursor.close();
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return coordinatesList;
    }

}

