package dev.teorerras.mygeofenceapp;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.IBinder;
import android.util.Log;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

public class TrackingService extends Service {

    private LocationManager locationManager;
    private LocationListener locationListener;
    private List<Coordinates> selectedAreas;
    private LatLng prevLocation;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        MainActivity.serviceRunning = true;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        selectedAreas = getSelectedAreas();
        prevLocation = null;


        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                for(Coordinates area: selectedAreas){

                    if(prevLocation == null){
                        if(pointInArea(location.getLatitude(), location.getLongitude(), area)){
                            saveToDatabase(location.getLatitude(), location.getLongitude(), Coordinates.ENTER_POINT);
                        }
                    }
                    else{
                        if(!pointInArea(prevLocation.latitude, prevLocation.longitude, area)){
                            if(pointInArea(location.getLatitude(), location.getLongitude(), area)){
                                saveToDatabase(location.getLatitude(), location.getLongitude(), Coordinates.ENTER_POINT);
                            }
                        }
                        else{
                            if(!pointInArea(location.getLatitude(), location.getLongitude(), area)){
                                saveToDatabase(prevLocation.latitude, prevLocation.longitude, Coordinates.OUT_POINT);
                            }
                        }
                    }
                }
                prevLocation = new LatLng(location.getLatitude(), location.getLongitude());
            }
        };
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 50, locationListener);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        locationManager.removeUpdates(locationListener);
        MainActivity.serviceRunning = false;
    }

    private List<Coordinates> getSelectedAreas(){

        List<Coordinates> coordinatesList = new ArrayList<>();

        Thread t = new Thread(() -> {

            ContentResolver resolver = getContentResolver();
            Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/getCoordinates/1");
            Cursor cursor = resolver.query(uri, null, null, null, null);

            if(cursor != null && cursor.moveToFirst()){
                do{
                    Coordinates c = new Coordinates();
                    c.id = cursor.getString(cursor.getColumnIndexOrThrow("id"));
                    c.latitude = cursor.getDouble(cursor.getColumnIndexOrThrow("lat"));
                    c.longitude = cursor.getDouble(cursor.getColumnIndexOrThrow("lng"));
                    c.pointType = cursor.getInt(cursor.getColumnIndexOrThrow("pt"));
                    c.session_id = cursor.getInt(cursor.getColumnIndexOrThrow("sid"));
                    coordinatesList.add(c);
                } while(cursor.moveToNext());
                cursor.close();
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return coordinatesList;
    }

    private boolean pointInArea(double lat, double lng, Coordinates area){
        final double R = 6371e3;
        double rlatA = Math.toRadians(lat);
        double rlngA = Math.toRadians(lng);
        double Dlat = Math.toRadians(Math.abs(lat - area.latitude));
        double Dlng = Math.toRadians(Math.abs(lng - area.longitude));

        double a, c, d;

        a = Math.pow(Math.sin(Dlat/2), 2) + Math.cos(rlatA) * Math.cos(rlngA) * Math.pow(Math.sin(Dlng/2), 2);
        c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        d = R * c;

        return d <= MapActivity.RADIUS;
    }

    private void saveToDatabase(double lat, double lon, int pt){
        Thread t = new Thread(() -> {
            ContentResolver resolver = getContentResolver();
            Uri uri = Uri.parse("content://dev.teorerras.mygeofenceapp/upsertCoordinates");
            ContentValues contentValues = new ContentValues();
            contentValues.put("lat", lat);
            contentValues.put("lng", lon);
            contentValues.put("pt", pt);
            contentValues.put("sid", MainActivity.LATEST_SESSION_ID);
            resolver.insert(uri, contentValues);});
        t.start();
        try {
            t.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

}
