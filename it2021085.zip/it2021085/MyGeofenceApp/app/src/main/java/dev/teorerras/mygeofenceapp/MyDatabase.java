package dev.teorerras.mygeofenceapp;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

@androidx.room.Database(entities = {Coordinates.class}, version = 1)
public abstract class MyDatabase extends RoomDatabase {
    public abstract CoordinatesDao coordinatesDao();

    // next code up to line 23 was taken from here: https://youtu.be/vSxKnvxe8v0?si=db1MGbOrQsA0sROZ
    private static volatile MyDatabase INSTANCE;
    private static MyDatabase getInstance(Context context){
        if(INSTANCE == null){
            synchronized (MyDatabase.class){
                if(INSTANCE == null){
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), MyDatabase.class, "COORDINATES_DB").build();
                }
            }
        }
        return INSTANCE;
    }//---------------------------------------------------------------------------------------------
    public static void initialize(Context context){
        INSTANCE = getInstance(context);
    }
    public static CoordinatesDao getCoordinatesDao(){
        if(INSTANCE != null){
            return INSTANCE.coordinatesDao();
        }
        return null;
    }
}
